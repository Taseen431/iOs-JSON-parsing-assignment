//
//  iosLab04App.swift
//  iosLab04
//
//  Created by Gaming Lab on 28/11/24.
//

import SwiftUI

@main
struct iosLab04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
