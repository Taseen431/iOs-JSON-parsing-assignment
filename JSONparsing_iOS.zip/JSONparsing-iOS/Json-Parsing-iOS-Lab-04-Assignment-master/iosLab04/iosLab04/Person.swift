//
//  person.swift
//  iosLab04
//
//  Created by Gaming Lab on 28/11/24.
//

import Foundation
