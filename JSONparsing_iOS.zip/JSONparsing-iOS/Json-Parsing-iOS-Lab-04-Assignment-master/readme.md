# iOS Lab04 Assignment: Json Parsing

## Roll : 2007033

## Screenshots:

## 1. Fetching Person Name from Json File
![Person](pic1.jpg)

## 2. Displaying Details When Clicking On a Person's Name
![Details](pic2.jpg)